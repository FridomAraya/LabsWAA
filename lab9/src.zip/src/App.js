import React, { useState } from "react";
import Dashboard from "./containers/Dashboard";
import "./App.css";

function App() {
  return (
    <div className="App">
      <h1> Welcome WAA </h1>
      <br />
      <br />
      <br />
      <Dashboard />
    </div>
  );
}

export default App;
