import React from 'react'

export const Selected = React.createContext([]);
